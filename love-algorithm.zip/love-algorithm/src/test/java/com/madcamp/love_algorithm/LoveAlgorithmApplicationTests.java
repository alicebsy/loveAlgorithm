package com.madcamp.love_algorithm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoveAlgorithmApplicationTests {

	@Test
	void contextLoads() {
	}

}
